const htmlText = ``;


const javaScriptText = ``;

export default { htmlText, javaScriptText };
